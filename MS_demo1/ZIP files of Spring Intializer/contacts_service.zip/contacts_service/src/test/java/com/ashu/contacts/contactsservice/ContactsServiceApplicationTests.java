package com.ashu.contacts.contactsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
